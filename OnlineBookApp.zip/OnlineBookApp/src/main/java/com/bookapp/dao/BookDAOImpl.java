package com.bookapp.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.bookapp.model.Book;


public class BookDAOImpl implements BookDAO {
	static SessionFactory factory;
	static {
		factory=HibernateUtil.getSessionFactory();
		
	}

	public void addOneBook(Book book) {
		
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Integer bookid=(Integer)session.save(book);
		System.out.println("inserted "+bookid);
		transaction.commit();
		session.close();
		
		
		
	}

	public int updateOneBook(int bookid, double price)  {
		
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Book book=session.get(Book.class, bookid);
		int num=0;
		if(book!=null) {
			book.setPrice(price);
			num=1;
			session.update(book);
		}
		
		transaction.commit();
		session.close();		
		return num;

	}

	public int deleteOneBook(int bookid) {
		
		
		Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        Book book = session.get(Book.class, bookid);
        int num=0;
        if(book!=null) {
            session.delete(book);
            num=1;
        }
        transaction.commit();
        session.close();
        return num;
	}

	public Book findBookById(int bookid){
		
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Book book=session.get(Book.class,bookid);
		transaction.commit();
		session.close();
		return book;

	}

	public List<Book> findAllBooks() {
		
		
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Query<Book> query=session.createQuery("from Book");
		List<Book> bookList=new ArrayList<>();
		bookList=query.list();
		transaction.commit();
		session.close();
		return bookList;
		
	}

	public List<Book> findBookByAuthor(String author) {
		
		
		
		
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		String sql = "from Book b where b.author like :choice";
		Query<Book> query=session.createQuery(sql).setParameter("choice", author);
		
		
		List<Book> bookList=new ArrayList<>();
		bookList=query.list();
		transaction.commit();
		session.close();
		
		return bookList;

	}

	public List<Book> findBookByCategory(String category)  {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		String sql = "from Book b where b.category like :choice";
		Query<Book> query = session.createQuery(sql).setParameter("choice", category);
		List<Book> bookList = new ArrayList<>();
		bookList = query.list();
		transaction.commit();
		session.close();
		return bookList;
		}

	}

	

