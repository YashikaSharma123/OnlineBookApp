package com.bookapp.exceptions;

public class AuthorNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AuthorNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AuthorNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
